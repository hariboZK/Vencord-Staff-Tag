﻿@echo off
color 0A
echo [=========================================]
echo   Vencord - Custom Plugin Installer
echo [=========================================]
echo.
echo Closing Discord...
taskkill /F /IM Discord.exe >nul 2>&1
timeout /t 2 >nul
echo.
echo Injecting Vencord...
set VENCORD_USER_DATA_DIR=%~dp0
set VENCORD_DEV_INSTALL=1
"%~dp0dist\Installer\VencordInstallerCli.exe" -install -branch stable
echo.
echo Installation complete! Restarting Discord...
start %LOCALAPPDATA%\Discord\Update.exe --processStart Discord.exe
echo.
echo Done! You can now close this window.
pause
